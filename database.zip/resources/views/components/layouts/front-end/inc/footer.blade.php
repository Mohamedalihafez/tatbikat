<footer class="footer">
    <div class="l-container">
      <div class="column">
        <h3 class="uppercase">{{ __("messages.about us") }}</h3>
        <ul>
          <li>
            <a href="">{{ __("messages.fire for businesses") }}</a>
          </li>
        </ul>
      </div>

      <div class="column">
        <h3 class="uppercase">{{ __("messages.fire") }}</h3>
        <ul>
          <li>
            <a href="">{{ __("messages.contact us") }}</a>
          </li>
        </ul>
      </div>

      <div class="column">
        <h3 class="uppercase">{{ __("messages.follow us") }}</h3>
        <ul class="social">
          <li>
            <a href=""><i class="bx bxl-facebook"></i></a>
          </li>

          <li>
            <a href=""><i class="bx bxl-twitter"></i></a>
          </li>

          <li>
            <a href=""><i class="bx bxl-instagram"></i></a>
          </li>
        </ul>
      </div>
    </div>
  </footer>