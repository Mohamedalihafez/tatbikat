
<p>{{ $city->governorate->name }}</p>