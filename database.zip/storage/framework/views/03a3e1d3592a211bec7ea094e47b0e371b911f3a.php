


<?php if (isset($component)) { $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad = $component; } ?>
<?php $component = App\View\Components\Layouts\FrontEnd\Application::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.front-end.application'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\FrontEnd\Application::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <section class="home">
      <div class="l-container">
        <div class="owl-carousel owl-theme home-content">
          <div class="item">
            <div class="item-container">
              <div class="box-img">
                <img src="<?php echo e(asset("frontEnd/assets/image/home/001.jpg")); ?>" alt="" />
              </div>

              <div class="item-details">
                <h1><?php echo e(__("messages.Lorem ipsum dolor")); ?></h1>
                <p>
                  <?php echo e(__("messages.Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore nulla quisquam modi nemo obcaecati in")); ?>

                </p>
              </div>
            </div>
          </div>

          <div class="item">
            <div class="item-container">
              <div class="box-img">
                <img src="<?php echo e(asset("frontEnd/assets/image/home/002.jpg")); ?>" alt="" />
              </div>

              <div class="item-details">
                <h1><?php echo e(__("messages.Lorem ipsum dolor")); ?></h1>
                <p>
                  <?php echo e(__("messages.Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore nulla quisquam modi nemo obcaecati in")); ?>

                </p>
              </div>
            </div>
          </div>

          <div class="item">
            <div class="item-container">
              <div class="box-img">
                <img src="<?php echo e(asset("frontEnd/assets/image/home/003.jpg")); ?>" alt="" />
              </div>

              <div class="item-details">
                <h1><?php echo e(__("messages.Lorem ipsum dolor")); ?></h1>
                <p>
                  <?php echo e(__("messages.Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore nulla quisquam modi nemo obcaecati in")); ?>

                </p>
              </div>
            </div>
          </div>

          <div class="item">
            <div class="item-container">
              <div class="box-img">
                <img src="<?php echo e(asset("frontEnd/assets/image/home/004.jpg")); ?>" alt="" />
              </div>

              <div class="item-details">
                <h1><?php echo e(__("messages.Lorem ipsum dolor")); ?></h1>
                <p>
                  <?php echo e(__("messages.Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore nulla quisquam modi nemo obcaecati in")); ?>

                </p>
              </div>
            </div>
          </div>

          <div class="item">
            <div class="item-container">
              <div class="box-img">
                <img src="<?php echo e(asset("frontEnd/assets/image/home/005.jpg")); ?>" alt="" />
              </div>

              <div class="item-details">
                <h1><?php echo e(__("messages.Lorem ipsum dolor")); ?></h1>
                <p>
                  <?php echo e(__("messages.Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore nulla quisquam modi nemo obcaecati in")); ?>

                </p>
              </div>
            </div>
          </div>
        </div>

        <div class="categories" id="categories">
          <div class="l-container">

            <div class="link" data-val="<?php echo e(App::getLocale() == "en" ? "special offer" : "عرض مميز"); ?>">
              <a href="">
                <span><?php echo e(__("messages.Featured ads")); ?></span>
                <span><i class='bx bx-spreadsheet'></i></span>
              </a>
            </div>

            <div class="link" data-val="trusted">
              <a href="">
                <span><?php echo e(__("messages.Certified ads")); ?></span>
                <span><i class='bx bx-spreadsheet'></i></span>
              </a>
            </div>

            <div class="link" data-val="last_24_hours">
              <a href="">
                <span><?php echo e(__("messages.Ads last 24 hours")); ?></span>
                <span><i class='bx bx-spreadsheet'></i></span>
              </a>
            </div>

          </div>
        </div>

        <div class="recommendations">
          <h2><?php echo e(__("messages.fresh recommendations")); ?></h2>

          <div class="recommendations-content">
            <?php if($offer_ads->count()): ?>
              <div class="recommendation-items" id="recommendation_items_offer">
                <?php $__currentLoopData = $offer_ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ad-card','data' => ['ad' => $ad,'class' => '']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ad-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ad' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ad),'class' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="flex justify-center items-center my-[1.5rem] w-full">
                <?php echo e($ads->links()); ?>

              </div>
            <?php else: ?>
              <div class="flex justify-center items-center w-full">
                <p class="text-[0.9rem] text-[#000000] capitalize font-[500]"><?php echo e(__("messages.no offers yet. please check back later")); ?></p>  
              </div>
            <?php endif; ?>
          </div>

          <div class="w-full h-[0.1rem] bg-slate-500 my-[1.5rem]"></div>

          <h2><?php echo e(__("messages.all ads")); ?></h2>

          <div class="recommendations-content">
            <?php if($ads->count()): ?>
              <div class="recommendation-items" id="recommendation_items">
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ad-card','data' => ['ad' => $ad,'class' => '']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ad-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ad' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ad),'class' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="flex justify-center items-center my-[1.5rem] w-full">
                <?php echo e($ads->links()); ?>

              </div>
            <?php else: ?>
              <div class="flex justify-center items-center w-full">
                <p class="text-[0.9rem] text-[#000000] capitalize font-[500]"><?php echo e(__("messages.no ads yet. please check back later")); ?></p>  
              </div>
            <?php endif; ?>
          </div>
          
        </div>
      </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
      <script>
        $(function () {
          $(".home .owl-carousel").owlCarousel({
              loop: true,
              items: 1,
              nav: false,
              dots: true,
              center: true,
              autoplay: true,
              animateOut: "fadeOut",
              rtl: true,
          });

          $(document).on("keyup", "#search_home", function () {
            let searchHome = $(this).val();
            
            $.ajax({
              type: "GET",
              url: "<?php echo e(route('home.search')); ?>",
              data: {
                "search": searchHome
              },
              cache: false,

              success: function (response) {
                $("#recommendation_items").html(response);
              }
            });
          })

          $(document).on("change", "#category_governorate_id", function () {
            let data = $(this).find(":selected").val();

            $.ajax({
              type: "GET",
              url: "<?php echo e(route('home.search')); ?>",
              data: {
                "category_governorate": data
              },
              cache: false,

              success: function (response) {
                $("#recommendation_items").html(response);
              }
            });
          });
          
          $(document).on("click", ".link", function(e) {
            e.preventDefault();
            let data = $(this).attr("data-val");

            if(data === "trusted") {
              $.ajax({
                type: "GET",
                url: "<?php echo e(route('home.search')); ?>",
                data: {
                  "certification": data
                },
                cache: false,

                success: function (response) {
                  $("#recommendation_items").html(response);
                }
              });
            }

            if(data == "last_24_hours"){
              $.ajax({
                type: "GET",
                url: "<?php echo e(route('home.search')); ?>",
                data: {
                  "last_day": data
                },
                cache: false,

                success: function (response) {
                  $("#recommendation_items").html(response);
                }
              });
            }

            if(data == "special offer" || data == "عرض مميز") {
              $.ajax({
                type: "GET",
                url: "<?php echo e(route('home.offer_name')); ?>",
                data: {
                  "offer_name": data
                },
                cache: false,

                success: function (response) {
                  $("#recommendation_items_offer").html(response);
                }
              });
            }
          });
        });
      </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad)): ?>
<?php $component = $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad; ?>
<?php unset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad); ?>
<?php endif; ?>

<?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/index.blade.php ENDPATH**/ ?>