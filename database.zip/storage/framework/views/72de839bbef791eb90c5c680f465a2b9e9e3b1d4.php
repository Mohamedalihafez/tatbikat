

<div class="w-full flex justify-center pt-[2rem] min-h-[100vh]">
    <ul class="inline-block">

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li wire:click="createConversation(<?php echo e($user->id); ?>)" class=" bg-slate-300 flex items-center justify-center w-[15rem] font-[700] my-[0.5rem] cursor-pointer py-[0.5rem]"><?php echo e($user->name); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/livewire/chat/create-chat.blade.php ENDPATH**/ ?>