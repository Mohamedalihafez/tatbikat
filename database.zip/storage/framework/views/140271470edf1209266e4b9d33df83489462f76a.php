<?php echo e($slot); ?>

<?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>