

<?php if (isset($component)) { $__componentOriginal39d162072dc6d9c61b3ccf6b0ba8bb53881499f4 = $component; } ?>
<?php $component = App\View\Components\Layouts\BackEnd\Application::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.back-end.application'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\BackEnd\Application::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"><?php echo e(__("admin.ads")); ?> /</span> <?php echo e(__("admin.Edit Ad")); ?></h4>

        <!-- Basic Layout -->
        <div class="row">
          <div class="col-xl">
            <div class="card mb-4">
              <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><?php echo e(__("admin.Edit Ad")); ?></h5>
                <small class="text-muted float-end"><?php echo e(__("admin.Edit Ad")); ?></small>
              </div>
              <div class="card-body">

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">Name</label>
                  <div class="input-group input-group-merge">
                      <span id="basic-icon-default-fullname2" class="input-group-text"
                          ><i class="bx bx-user"></i
                      ></span>
                      <input
                          type="text"
                          class="form-control"
                          id="basic-icon-default-fullname"
                          disabled
                          value="<?php echo e($ad->name); ?>"
                          aria-describedby="basic-icon-default-fullname2"
                      />
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">Slug</label>
                  <div class="input-group input-group-merge">
                      <span id="basic-icon-default-fullname2" class="input-group-text"
                          ><i class="bx bx-user"></i
                      ></span>
                      <input
                          type="text"
                          class="form-control"
                          id="basic-icon-default-fullname"
                          disabled
                          value="<?php echo e($ad->slug); ?>"
                          aria-describedby="basic-icon-default-fullname2"
                      />
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">Brand</label>
                  <?php if($ad->brand != null): ?>
                    <div class="input-group">
                      <label class="input-group-text" for="inputGroupSelect01">Brand</label>
                      <select class="form-select" disabled id="inputGroupSelect01" name="governorate_id">
                          <option selected><?php echo e($ad->brand->name); ?></option>
                      </select>
                    </div>
                  <?php else: ?> 
                  <div class="form-label" for="basic-icon-default-fullname">No Brand</div>
                  <?php endif; ?>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">type</label>
                  <?php if($ad->type != null): ?>
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        id="active"
                        checked
                        disabled
                      />
                      <label class="form-check-label" for="active"> <?php echo e($ad->type); ?> </label>
                    </div>
                  <?php else: ?>
                  <div class="form-label" for="basic-icon-default-fullname">no type</div>
                  <?php endif; ?>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">condition</label>
                  <?php if($ad->condition != null): ?>
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      checked
                      disabled
                    />
                    <label class="form-check-label" for="active"> <?php echo e($ad->condition); ?> </label>
                  </div>
                  <?php else: ?>
                      <div class="form-label">no condition</div>
                  <?php endif; ?>
                </div>

                <div class="mb-3">
                  <label for="exampleFormControlTextarea1" class="form-label">Description</label>
                  <textarea class="form-control" rows="3" disabled><?php echo e($ad->description); ?></textarea>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">price</label>
                  <div class="input-group input-group-merge">
                      <span id="basic-icon-default-fullname2" class="input-group-text"
                          ><i class="bx bx-user"></i
                      ></span>
                      <input
                          type="text"
                          class="form-control"
                          id="basic-icon-default-fullname"
                          disabled
                          value="<?php echo e($ad->price); ?>"
                          aria-describedby="basic-icon-default-fullname2"
                      />
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">Basic Image</label>
                  <div class="input-group input-group-merge">
                      <img src="<?php echo e(asset("upload_files/ads/" . $ad->thumbnail)); ?>" style="width: 10rem; height:7rem" alt="">
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">Ad Images</label>
                  <div class="input-group input-group-merge" style="flex-wrap: wrap">
                    <?php $__currentLoopData = $ad->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <img src="<?php echo e(asset("upload_files/ads/" . $picture->thumbnail)); ?>" style="width: 10rem; height:7rem; margin-right: 0.5rem; margin-bottom: 0.5rem;" alt="">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">governorate</label>
                  <div class="input-group">
                    <label class="input-group-text" for="inputGroupSelect01">Governorate</label>
                    <select class="form-select" disabled id="inputGroupSelect01" name="governorate_id">
                        <option selected><?php echo e($ad->governorate->name); ?></option>
                    </select>
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">city</label>
                  <div class="input-group">
                    <label class="input-group-text" for="inputGroupSelect01">City</label>
                    <select class="form-select" disabled id="inputGroupSelect01" name="governorate_id">
                        <option selected><?php echo e($ad->city->name); ?></option>
                    </select>
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">Name of User</label>
                  <div class="input-group input-group-merge">
                      <span id="basic-icon-default-fullname2" class="input-group-text"
                          ><i class="bx bx-user"></i
                      ></span>
                      <input
                          type="text"
                          class="form-control"
                          id="basic-icon-default-fullname"
                          disabled
                          value="<?php echo e($ad->user_name); ?>"
                          aria-describedby="basic-icon-default-fullname2"
                      />
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">phone of User</label>
                  <div class="input-group input-group-merge">
                      <span id="basic-icon-default-fullname2" class="input-group-text"
                          ><i class="bx bx-user"></i
                      ></span>
                      <input
                          type="text"
                          class="form-control"
                          id="basic-icon-default-fullname"
                          disabled
                          value="<?php echo e($ad->user_phone); ?>"
                          aria-describedby="basic-icon-default-fullname2"
                      />
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">contact</label>
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      checked
                      disabled
                    />
                    <label class="form-check-label" for="active"> <?php echo e($ad->contact); ?> </label>
                  </div>
                </div>

                <form method="POST" action="<?php echo e(route("admin.ads.update", $ad->slug)); ?>" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PATCH"); ?>

                    
                    <div class="mb-3">
                      <label class="form-label" for="basic-icon-default-fullname"><?php echo e(__("admin.certification")); ?></label>
                      <div class="form-check">
                          <input
                              name="certification"
                              class="form-check-input"
                              type="radio"
                              value="trusted"
                              id="trusted"
                              <?php echo e($ad->certification == "trusted" ? "checked" : ""); ?>

                          />
                          <label class="active" for="trusted"> Trusted </label>
                      </div>

                      <div class="form-check">
                          <input
                              name="certification"
                              class="form-check-input"
                              type="radio"
                              value="untrusted"
                              id="untrusted"
                              <?php echo e($ad->certification == "untrusted" ? "checked" : ""); ?>

                          />
                          <label class="form-check-label" for="untrusted"> Untrusted </label>
                      </div>

                      <div class="form-check">
                          <input
                              name="certification"
                              class="form-check-input"
                              type="radio"
                              value="moderated"
                              id="moderated"
                              <?php echo e($ad->certification == "moderated" ? "checked" : ""); ?>

                          />
                          <label class="form-check-label" for="moderated"> Moderated </label>
                      </div>
                    </div>

                    
                    <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-fullname"><?php echo e(__("admin.Status")); ?></label>
                        <div class="form-check">
                            <input
                                name="status"
                                class="form-check-input"
                                type="radio"
                                value="active"
                                id="active"
                                <?php echo e($ad->status == "active" ? "checked" : ""); ?>

                            />
                            <label class="active" for="active"> Active </label>
                        </div>

                        <div class="form-check">
                            <input
                                name="status"
                                class="form-check-input"
                                type="radio"
                                value="inactive"
                                id="inactive"
                                <?php echo e($ad->status == "inactive" ? "checked" : ""); ?>

                            />
                            <label class="form-check-label" for="inactive"> Inactive </label>
                        </div>

                        <div class="form-check">
                            <input
                            name="status"
                            class="form-check-input"
                            type="radio"
                            value="pending"
                            id="pending"
                            <?php echo e($ad->status == "pending" ? "checked" : ""); ?>

                            />
                            <label class="form-check-label" for="pending"> Pending </label>
                        </div>

                        <div class="form-check">
                            <input
                                name="status"
                                class="form-check-input"
                                type="radio"
                                value="moderated"
                                id="moderated"
                                <?php echo e($ad->status == "moderated" ? "checked" : ""); ?>

                            />
                            <label class="form-check-label" for="moderated"> Moderated </label>
                        </div>
                    </div>
                  
                  <button type="submit" class="btn btn-primary"><?php echo e(__("admin.update")); ?></button>
                </form>
              </div>
            </div>
          </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39d162072dc6d9c61b3ccf6b0ba8bb53881499f4)): ?>
<?php $component = $__componentOriginal39d162072dc6d9c61b3ccf6b0ba8bb53881499f4; ?>
<?php unset($__componentOriginal39d162072dc6d9c61b3ccf6b0ba8bb53881499f4); ?>
<?php endif; ?><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/admin/ads/edit.blade.php ENDPATH**/ ?>