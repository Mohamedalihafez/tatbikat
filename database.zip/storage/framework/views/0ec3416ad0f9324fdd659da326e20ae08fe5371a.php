<form action="<?php echo e(route("admin.users.update", $username)); ?>" style="display: inline-block" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PATCH"); ?>

    <button type="submit" class="delete btn btn-success btn-sm">Update as Admin</button>
</form><?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/admin/users/dataTables/actions.blade.php ENDPATH**/ ?>