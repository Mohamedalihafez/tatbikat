
<option selected disabled>
    <?php echo e(__("post.Choosing City") . " ..."); ?>

</option>
<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($city->id); ?>">
        <span><?php echo e($city->translate()->name); ?></span>
    </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/ad/cities.blade.php ENDPATH**/ ?>