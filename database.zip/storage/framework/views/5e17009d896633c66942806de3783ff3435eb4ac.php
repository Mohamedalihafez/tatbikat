
<?php $__currentLoopData = $governorate->cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h6><?php echo e($city->name); ?></h6>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/admin/governorates/dataTables/cities.blade.php ENDPATH**/ ?>