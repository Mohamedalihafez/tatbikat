
<div class="w-full h-full">

    <?php if($selectedConversation): ?>
        <div class="w-full h-full border-t-[0.1rem] border-slate-500">
        
            <div class="w-full h-full px-[1rem]">
                <form action="" wire:submit.prevent="sendMessage" class="w-full h-full flex items-center">
                    <input type="text" wire:model="body" placeholder="Write message" class="flex-1 h-[2.8rem] text-[0.85rem] rounded-[0.5rem] bg-slate-300 border-0 focus:outline-none focus:ring focus:border-blue-500">
                    <button type="submit" class="ml-[1rem] uppercase text-[1rem] font-[800] text-blue-500">send</button>
                </form>
            </div>
            
        </div>
    <?php endif; ?>
</div>

<?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/livewire/chat/send-message.blade.php ENDPATH**/ ?>