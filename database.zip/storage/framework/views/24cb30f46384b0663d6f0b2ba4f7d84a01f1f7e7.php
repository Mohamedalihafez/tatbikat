<!DOCTYPE html>
<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
    />

    <?php if(App::getLocale() === "ar"): ?>
      <!-- STYLING -->
      <link rel="stylesheet" href="<?php echo e(asset("frontEnd/assets/css/ar/main.css")); ?>" />

      
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800;900;1000&display=swap" rel="stylesheet">
    <?php else: ?>
      <!-- STYLING -->
      <link rel="stylesheet" href="<?php echo e(asset("frontEnd/assets/css/en/main.css")); ?>" />

      <!-- FONTS OF SITE -->
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
      <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet"
      />
    <?php endif; ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <title>On Fire | Login</title>
  </head>
  <body>

    
    <?php echo $__env->make('components.layouts.guest.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo e($slot); ?>

    

  </body>
</html>
<?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/components/layouts/guest/application.blade.php ENDPATH**/ ?>