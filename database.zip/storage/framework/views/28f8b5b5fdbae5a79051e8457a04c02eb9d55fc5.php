

<?php if (isset($component)) { $__componentOriginal33730d8d01d2763b4adc0ed86234a7f78a01d162 = $component; } ?>
<?php $component = App\View\Components\Layouts\Guest\Application::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.guest.application'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\Guest\Application::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="l-container">
        <section class="section register">
          <div class="register-box">
            <div class="register-header">
              <h1><?php echo e(__("messages.register")); ?></h1>
            </div>
  
            <form action="<?php echo e(route("register")); ?>" method="POST" autocomplete="off">
                <?php echo csrf_field(); ?>

              <div class="row">
                <div class="box-input">
                  <input
                    type="text"
                    id="name"
                    placeholder="<?php echo e(__("messages.name")); ?>"
                    name="name"
                    value="<?php echo e(old("name")); ?>"
                    autofocus
                  />
                </div>
                <div class="box-input-error">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="row">
                <div class="box-input">
                  <input
                    type="text"
                    id="username"
                    placeholder="<?php echo e(__("messages.username")); ?>"
                    name="username"
                    value="<?php echo e(old("username")); ?>"
                  />
                </div>
                <div class="box-input-error">
                  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="row">
                <div class="box-input">
                  <input
                    type="text"
                    id="email"
                    placeholder="<?php echo e(__("messages.email")); ?>"
                    name="email"
                    value="<?php echo e(old("email")); ?>"
                  />
                </div>
                <div class="box-input-error">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="row">
                <div class="box-input">
                  <input
                    type="password"
                    id="password"
                    placeholder="<?php echo e(__("messages.password")); ?>"
                    name="password"
                  />
                </div>
                <div class="box-input-error">
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="row">
                <div class="box-input">
                  <input
                    type="password"
                    id="password"
                    placeholder="<?php echo e(__("messages.password confirmation")); ?>"
                    name="password_confirmation"
                  />
                </div>
              </div>

                <?php if(Laravel\Jetstream\Jetstream::hasTermsAndPrivacyPolicyFeature()): ?>
                    <div class="mt-4">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.label','data' => ['for' => 'terms']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'terms']); ?>
                            <div class="flex items-center">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.checkbox','data' => ['name' => 'terms','id' => 'terms']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'terms','id' => 'terms']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                <div class="ml-2">
                                    <?php echo __('I agree to the :terms_of_service and :privacy_policy', [
                                            'terms_of_service' => '<a target="_blank" href="'.route('terms.show').'" class="underline text-sm text-gray-600 hover:text-gray-900">'.__('Terms of Service').'</a>',
                                            'privacy_policy' => '<a target="_blank" href="'.route('policy.show').'" class="underline text-sm text-gray-600 hover:text-gray-900">'.__('Privacy Policy').'</a>',
                                    ]); ?>

                                </div>
                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                <?php endif; ?>
  
              <div class="row mt-[2.5rem]">
                <div class="box-submit">
                  <button type="submit"><?php echo e(__("messages.register")); ?></button>
                </div>
              </div>
  
              <p class="sign-in">
                <span><?php echo e(__("messages.already have an account")); ?></span>
                <a href="<?php echo e(route("login")); ?>">
                  <span><?php echo e(__("messages.signin instead")); ?></span>
                </a>
              </p>
            </form>
          </div>
        </section>
      </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal33730d8d01d2763b4adc0ed86234a7f78a01d162)): ?>
<?php $component = $__componentOriginal33730d8d01d2763b4adc0ed86234a7f78a01d162; ?>
<?php unset($__componentOriginal33730d8d01d2763b4adc0ed86234a7f78a01d162); ?>
<?php endif; ?>
<?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/auth/register.blade.php ENDPATH**/ ?>