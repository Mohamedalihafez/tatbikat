<a href="<?php echo e(route("admin.categories.edit", $slug)); ?>" class="edit btn btn-success btn-sm">Edit</a>

<form action="<?php echo e(route("admin.categories.destroy", $slug)); ?>" style="display: inline-block" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("DELETE"); ?>

    <button type="submit" class="delete btn btn-danger btn-sm">Delete</button>
</form><?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/admin/categories/mainCategories/dataTables/actions.blade.php ENDPATH**/ ?>