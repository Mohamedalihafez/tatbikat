<a href="<?php echo e(route("admin.transactions.edit", $id)); ?>" class="edit btn btn-success btn-sm">Edit</a>

<form action="<?php echo e(route("admin.transactions.destroy", $id)); ?>" style="display: inline-block" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("DELETE"); ?>

    <button type="submit" class="delete btn btn-danger btn-sm">Delete</button>
</form><?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/admin/transactions/dataTables/actions.blade.php ENDPATH**/ ?>