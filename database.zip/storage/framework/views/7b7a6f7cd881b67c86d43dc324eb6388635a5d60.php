

<?php if (isset($component)) { $__componentOriginal33730d8d01d2763b4adc0ed86234a7f78a01d162 = $component; } ?>
<?php $component = App\View\Components\Layouts\Guest\Application::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.guest.application'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\Guest\Application::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

  <div class="l-container">
      <section class="section register">
        <?php if(session('status')): ?>
          <div class="mb-4 mt-4 font-medium text-sm text-green-600">
              <?php echo e(session('status')); ?>

          </div>
        <?php endif; ?>

        <div class="register-box">
          <div class="register-header">
            <h1><?php echo e(__("messages.welcome back")); ?></h1>
          </div>

          <form action="<?php echo e(route("login")); ?>" method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>

            <div class="row">
              <div class="box-input">
                <input
                  type="text"
                  id="email"
                  placeholder="<?php echo e(__("messages.email")); ?>"
                  name="email"
                  value="<?php echo e(old("email")); ?>"
                />
              </div>
              <div class="box-input-error">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

            <div class="row">
              <div class="box-input">
                <input
                  type="password"
                  id="password"
                  placeholder="<?php echo e(__("messages.password")); ?>"
                  name="password"
                />
              </div>
            </div>

            <div class="row mt-[1rem]">
              <div class="flex items-center justify-end">
                <?php if(Route::has('password.request')): ?>
                    <a class="underline text-sm text-black hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('messages.Forgot your password')); ?>

                    </a>
                <?php endif; ?>
              </div>
            </div>

            <div class="row mt-[1.5rem]">
              <div class="box-submit">
                <button type="submit"><?php echo e(__("messages.login")); ?></button>
              </div>
            </div>

            <div class="w-full my-[2rem] flex justify-center">
              <div class="w-auto">
                <a href="<?php echo e(route("auth.google")); ?>" class="bg-red-600 text-[0.95rem] text-white font-[500] capitalize px-[3rem] py-[0.7rem] rounded-full">
                  <i class="fa-brands fa-google mr-[0.5rem]"></i>
                  login with google
                </a>
              </div>
            </div>

            <p class="sign-in">
              <span><?php echo e(__("messages.haven't an account")); ?></span>
              <a href="<?php echo e(route("register")); ?>">
                <span><?php echo e(__("messages.signin")); ?></span>
              </a>
            </p>
          </form>
        </div>
      </section>
  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal33730d8d01d2763b4adc0ed86234a7f78a01d162)): ?>
<?php $component = $__componentOriginal33730d8d01d2763b4adc0ed86234a7f78a01d162; ?>
<?php unset($__componentOriginal33730d8d01d2763b4adc0ed86234a7f78a01d162); ?>
<?php endif; ?>
<?php /**PATH C:\Users\alimo\OneDrive\Desktop\project_suadia\onfire.tutbekat.com\resources\views/auth/login.blade.php ENDPATH**/ ?>