

<div class="w-[30rem] min-h-full border-r-[0.1rem] border-slate-800">
<div class="w-full h-[4.3rem] flex items-center px-[1rem] bg-slate-200 border-b-[0.1rem] border-slate-400">
    <h1 class="uppercase text-[1.3rem] font-[700]">inbox</h1>
</div>

<div class="px-[0.7rem] w-full h-full overflow-y-auto">

    <?php if($conversations->count() > 0): ?>
        <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-full h-[4rem] bg-slate-200 px-[0.3rem] rounded-[0.8rem] flex items-center justify-between my-[0.5rem] cursor-pointer hover:bg-slate-300"
                wire:click="$emit('chatUserSelected', <?php echo e($conversation); ?>, <?php echo e($this->getChatUserInstance($conversation, $name="id")); ?>)"
                wire:key="<?php echo e($conversation->id); ?>"
            >
                <div class="w-[2.5rem] h-[2.5rem] bg-slate-400 rounded-full mr-[0.5rem] overflow-hidden">
                    <img src="https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=<?php echo e($this->getChatUserInstance($conversation, $name="name")); ?>" alt="" class="w-full h-full object-cover">
                </div>
                <div class="w-[22rem] mr-[0.5rem]">
                    <div class="mb-[0.1rem] w-full truncate">
                        <h1 class="font-[800] text-[#000000] text-[0.95rem]"><?php echo e($this->getChatUserInstance($conversation, $name="name")); ?></h1>
                    </div>
                    <div class="w-full truncate">
                        <p class="text-[0.8rem] font-[400] text-[#555555]">
                            <?php echo e($conversation->messages->last()->body); ?>

                        </p>
                    </div>
                </div>
                <div class="flex flex-col items-center w-[2rem]">
                    <div class="flex items-center justify-center">
                        <p class="text-[0.85rem] font-[600]"><?php echo e($conversation->messages->last()?->created_at->shortAbsoluteDiffForHumans()); ?></p>
                    </div>
                    <div class="flex items-center justify-center">
                        <p class="px-[0.2rem] py-[0.15rem] bg-red-700 rounded-full text-[0.9rem] font-[600] text-[#f1f1f1] leading-[1]">12</p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="w-full h-full flex justify-center items-center">
            <p class="text-[0.9rem] font-[700] capitalize">you not have conversations</p>
        </div>
    <?php endif; ?>
    
</div>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/livewire/chat/chat-list.blade.php ENDPATH**/ ?>