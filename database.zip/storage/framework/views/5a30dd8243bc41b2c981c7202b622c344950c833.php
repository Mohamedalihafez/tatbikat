
<?php $__currentLoopData = $mainCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h6><?php echo e($subCategory->name); ?></h6>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/admin/categories/mainCategories/dataTables/subCategory.blade.php ENDPATH**/ ?>