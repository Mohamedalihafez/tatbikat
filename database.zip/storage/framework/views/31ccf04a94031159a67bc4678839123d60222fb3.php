
<?php if($ads->count()): ?>
    <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="recommendation-item">
            <div class="img">
                <img class="w-full h-full" src="<?php echo e(asset("upload_files/ads/" . $ad->thumbnail)); ?>" alt="<?php echo e($ad->name); ?>" />
            </div>

            <div class="details">
                <a href="<?php echo e(route("posts.show", $ad->slug)); ?>">
                    <h3 class="truncate"><?php echo e($ad->name); ?></h3>
                </a>
                <h2><?php echo e(__("messages.egp") . " " . $ad->price); ?></h2>
                <p class="mb-[0.7rem] capitalize"><?php echo e($ad->city->name . ", " . $ad->governorate->name); ?></p>
                <p class="capitalize"><?php echo e($ad->created_at->diffForHumans()); ?></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="flex justify-center items-center w-full">
        <p class="text-[0.9rem] text-[#000000] capitalize font-[500]"><?php echo e(__("messages.no result match value of search")); ?></p>  
    </div>
<?php endif; ?><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/filter_offers.blade.php ENDPATH**/ ?>