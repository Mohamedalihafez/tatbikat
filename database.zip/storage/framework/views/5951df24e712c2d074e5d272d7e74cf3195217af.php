

<li class="sub_menu-link">
    <?php echo e($slot); ?>

</li><?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/components/sub-menu-link.blade.php ENDPATH**/ ?>