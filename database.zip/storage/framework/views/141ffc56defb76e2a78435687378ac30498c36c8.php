
<p><?php echo e($city->governorate->name); ?></p><?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/admin/cities/dataTables/governorate.blade.php ENDPATH**/ ?>