<?php

return [

    "skip, show your ad" => "Skip, show your ad",
    "promote your ad" => "Promote your ad",
    "no offers yet" => "no offers yet.!",
    "what to do next" => "What to do next",
    "No enough money in your wallet, please charge your wallet and try again" => "No enough money in your wallet, please charge your wallet and try again",


];