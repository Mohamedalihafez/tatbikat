<?php

return [

    "skip, show your ad" => "تخطي ، اعرض إعلانك",
    "promote your ad" => "روج لإعلانك",
    "no offers yet" => "لا يوجد عروض حتى الان",
    "what to do next" => "ما يجب القيام به بعد ذلك",
    "No enough money in your wallet, please charge your wallet and try again" => "لا يوجد نقود كافية في محفظتك ، يرجى شحن محفظتك والمحاولة مرة أخرى",

];