<?php 

return [

    "charging the wallet via vodafone cash" => "شحن المحفظة عبر فودافون كاش",
    "peyment details" => "بيانات الدفع",
    "the mobile number to which the amount will be transferred" => "رقم الهاتف المحمول الذي سيتم تحويل المبلغ إليه",
    "please enter your name" => "من فضلك أدخل إسمك",
    "please enter the number" => "الرجاء إدخال الرقم",
    "please enter your message" => "أدرج رسالتك من فضلك",
    "after transferring the amount to the number, enter the following data" => "بعد تحويل المبلغ إلى الرقم ، أدخل البيانات التالية",
    "send" => "إرسال",
    "the number from which it was converted" => "الرقم الذي تم تحويله منه",
    "successfully sent, the information will be verified and the amount in the wallet will be transferred soon" => "تم الإرسال بنجاح ، سيتم التحقق من المعلومات وسيتم تحويل المبلغ الموجود في المحفظة قريبًا",

];