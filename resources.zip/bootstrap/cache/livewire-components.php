<?php return array (
  'chat.chat-list' => 'App\\Http\\Livewire\\Chat\\ChatList',
  'chat.chatbox' => 'App\\Http\\Livewire\\Chat\\Chatbox',
  'chat.create-chat' => 'App\\Http\\Livewire\\Chat\\CreateChat',
  'chat.main' => 'App\\Http\\Livewire\\Chat\\Main',
  'chat.send-message' => 'App\\Http\\Livewire\\Chat\\SendMessage',
);