<?php

return [
    
    "edit" => "edit",
    "delete" => "delete",

    "favorites" => "favorites",
    "ads" => "ads",
    "search by ad title or id" => "search by ad title or id",
    "filter by category" => "filter by category",
    "view all" => "view all",
    "active ads" => "active ads",
    "inactive ads" => "inactive ads",
    "pending ads" => "pending ads",
    "moderated ads" => "moderated ads",

    // POst Ad
    "description" => "description",
    "condition" => "condition",
    "price" => "price",
    "brand" => "brand",
    "price type" => "price type",
    "is deliverable" => "is deliverable",
    "no" => "no",
    "details" => "details",
    "egp" => "egp",
    "seller description" => "seller description",
    "member since" => "member since",
    "your safety matters to us" => "your safety matters to us",

    "only meet in public / crowded places for example metro stations and malls" => "Only meet in public / crowded places for example metro stations and malls.",

    "tel" => "Tel",
    "send message" => "Send Message",
    "share on social media" => "share on social media",

    
];