<?php 

return [

    "charging the wallet via vodafone cash" => "Charging the wallet via Vodafone Cash",
    "peyment details" => "peyment details",
    "the mobile number to which the amount will be transferred" => "the mobile number to which the amount will be transferred",
    "please enter your name" => "please enter your name",
    "please enter the number" => "please enter the number",
    "please enter your message" => "please enter your message",
    "after transferring the amount to the number, enter the following data" => "After transferring the amount to the number, enter the following data",
    "send" => "send",
    "the number from which it was converted" => "The number from which it was converted",
    "successfully sent, the information will be verified and the amount in the wallet will be transferred soon" => "Successfully sent, the information will be verified and the amount in the wallet will be transferred soon",

];