<?php

return [

    "fire" => "fire",
    "back to home" => "Back to Home",
    "searching for what" => "Searching for what.?",
    "my profile" => "my profile",
    "my ads" => "my ads",
    "logout" => "logout",
    "login" => "login",
    "signin" => "signin",
    "register" => "register",
    "welcome back" => "welcome back",
    "name" => "name",
    "username" => "username",
    "email" => "email",
    "password" => "password",
    "password confirmation" => "password confirmation",
    "haven't an account" => "Haven't an account?",
    "already have an account" => "Already have an account?",
    "signin instead" => "signin instead",
    "fire wallet" => "fire wallet",
    "balance" => "balance",
    "egp" => "EGP",
    "select your city" => "Select Your City",
    "sell" => "sell",
    "language" => "language",
    "fresh recommendations" => "fresh recommendations",
    "all ads" => "all ads",

    "Lorem ipsum dolor" => "Lorem ipsum dolor",
    "Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore nulla quisquam modi nemo obcaecati in" => "Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore nulla quisquam modi nemo obcaecati in",


    // Footer
    "follow us" => "follow us",
    "about us" => "about us",
    "fire for businesses" => "fire for businesses",
    "contact us" => "contact us",

    // Login
    "Forgot your password" => "Forgot your password?",

    "no offers yet. please check back later" => "no offers yet. please check back later",
    "no ads yet. please check back later" => "no ads yet. please check back later",

    "Featured ads" => "Featured ads",
    "Certified ads" => "Certified ads",
    "Ads last 24 hours" => "Ads last 24 hours",

    "no result match value of search" => "no result match value of search",

    
];