
<?php if (isset($component)) { $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad = $component; } ?>
<?php $component = App\View\Components\Layouts\FrontEnd\Application::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.front-end.application'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\FrontEnd\Application::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <section class="create_offer my-[2rem]">
        <div class="l-container">
          <div class="create_offer_content">
            <form action="<?php echo e(route("posts.update", $ad->slug)); ?>" id="form" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php echo method_field("PATCH"); ?>

              <div class="head_form">
                <h2><?php echo e(__("post.update some details")); ?></h2>
              </div>
  
              
              <div class="box_input">
                <label for="Ad_title"><?php echo e(__("post.ad title")); ?></label>
                <input type="text" class="input" id="Ad_title" name="name" value="<?php echo e(old("name", $ad->name)); ?>" />
                <div class="error_message">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input">
                <label for="Ad_slug"><?php echo e(__("post.ad slug")); ?></label>
                <input type="text" class="input" id="Ad_slug" name="slug" value="<?php echo e(old("slug", $ad->slug)); ?>" />
                <div class="error_message">
                  <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input">
                <label for="Brand"><?php echo e(__("post.brand")); ?> <span class="text-[0.75rem] text-slate-400"><?php echo e(__("post.option")); ?></span></label>
                <select name="brand_id" id="Brand">
                  <option selected disabled>
                    <?php echo e(__("post.choosing brand") . "..."); ?>

                  </option>

                  <?php $__currentLoopData = App\Models\Brand::where("status", "active")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(old("brand_id", $ad->brand_id) == $brand->id ? "selected" : ""); ?> value="<?php echo e($brand->id); ?>">
                      <span><?php echo e($brand->name); ?></span>
                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="error_message">
                  <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input">
                <label><?php echo e(__("post.type")); ?> <span class="text-[0.75rem] text-slate-400"><?php echo e(__("post.option")); ?></span></label>

                <div class="flex mt-[1rem]">
                  <label for="radio_type_1" class="radio_method <?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_type_1" class="<?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="type" value="phone" <?php echo e($ad->type === "phone" ? "checked" : ""); ?> />
                    <span>Phone number</span>
                  </label>

                  <label for="radio_type_2" class="radio_method <?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_type_2" class="<?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="type" value="chat" <?php echo e($ad->type === "chat" ? "checked" : ""); ?> />
                    <span>chat</span>
                  </label>

                  <label for="radio_type_3" class="radio_method">
                    <input type="radio" id="radio_type_3" class="<?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="type" value="both" <?php echo e($ad->type === "both" ? "checked" : ""); ?> />
                    <span>BOTH</span>
                  </label>
                </div>

                <div class="error_message">
                  <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input">
                <label><?php echo e(__("post.condition")); ?> <span class="text-[0.75rem] text-slate-400"><?php echo e(__("post.option")); ?></span></label>

                <div class="flex mt-[1rem]">
                  <label for="radio_condition_new" class="radio_method <?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_condition_new" class="<?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="condition" value="new" <?php echo e($ad->condition === "new" ? "checked" : ""); ?> />
                    <span><?php echo e(__("post.New")); ?></span>
                  </label>

                  <label for="radio_condition_old" class="radio_method <?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_condition_old" class="<?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="condition" value="used" <?php echo e($ad->condition === "used" ? "checked" : ""); ?> />
                    <span><?php echo e(__("post.used")); ?></span>
                  </label>
                </div>

                <div class="error_message">
                  <?php $__errorArgs = ['condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              
              <div class="box_input">
                <label for="Description"><?php echo e(__("post.Description")); ?></label>
                <textarea name="description" id="Description"><?php echo e(old("description", $ad->description)); ?></textarea>
                <div class="error_message">
                  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="border bg-black"></div>
  
              
              <h2 class="uppercase font-[800] text-[1.25rem] mb-[0.7rem]"><?php echo e(__("post.set a price")); ?></h2>
              <div class="box_input">
                <label for="price"><?php echo e(__("post.price")); ?></label>
                <input type="number" class="input" id="price" name="price" value="<?php echo e(old("price", $ad->price)); ?>" />
                <div class="error_message">
                  <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="border bg-black"></div>

              
              <h2 class="uppercase font-[800] text-[1.25rem] mb-[0.7rem]"><?php echo e(__("post.UPLOAD UP PHOTOS")); ?></h2>
              <div class="box_input">
                <label for="photos"><?php echo e(__("post.upload basic photo")); ?></label>
                <input
                  type="file"
                  id="photos"
                  name="thumbnail"
                  class="custom-file-input input"
                  accept="image/png, image/jpeg"
                />
                <div class="my-[0.5rem] w-[13rem] h-[10rem]">
                    <img class="w-full h-full rounded-[1rem]" src="<?php echo e(asset("upload_files/ads/" . $ad->thumbnail)); ?>" alt="">
                </div>
                <div class="error_message">
                  <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              
              <div class="box_input">
                <label for="photos"><?php echo e(__("post.upload up top 5 photos")); ?></label>
                <input
                  type="file"
                  id="photos"
                  name="thumbnails[]"
                  class="custom-file-input input"
                  accept="image/png, image/jpeg"
                  multiple
                />
                <div class="my-[0.5rem] flex flex-wrap">
                    <?php $__currentLoopData = $ad->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img class="rounded-[1rem] w-[13rem] h-[10rem] mr-[0.5rem] mb-[0.5rem]" src="<?php echo e(asset("upload_files/ads/" . $picture->thumbnail)); ?>" alt="">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="error_message">
                  <?php $__errorArgs = ['thumbnails'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="border bg-black"></div>

              
              <h2 class="uppercase font-[800] text-[1.25rem] mb-[0.7rem]"><?php echo e(__("post.YOUR AD'S location")); ?></h2>
              <div class="box_input">
                <label for="Brand"><?php echo e(__("post.Location")); ?></label>
                <select name="governorate_id" id="governorate_id">
                  <option selected disabled>
                    <?php echo e(__("post.Choosing Location") . "..."); ?>

                  </option>
  
                  <?php $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($governorate->id); ?>" <?php echo e($ad->governorate_id == $governorate->id ? "selected" : ""); ?>>
                      <span><?php echo e($governorate->name); ?></span>
                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="error_message">
                  <?php $__errorArgs = ['governorate_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input">
                <label for="Brand"><?php echo e(__("post.Select Cities")); ?></label>
                <select name="city_id" id="city_id">
                    <option selected disabled>
                      <?php echo e(__("post.Choosing Location") . "..."); ?>

                    </option>
    
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city->id); ?>" <?php echo e($ad->city_id == $city->id ? "selected" : ""); ?>>
                        <span><?php echo e($city->name); ?></span>
                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="error_message">
                  <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="border bg-black"></div>
  
              <h2 class="text-[1.25rem] font-[800] mb-[1rem] uppercase text-black"><?php echo e(__("post.REVIEW YOUR DETAILS")); ?></h2>
  
              <div class="flex mb-[1.5rem]">
                <div class="w-[5.5rem] h-[5.5rem] rounded-full mr-[1.3rem]">
                  <img class="w-full h-full" src="<?php echo e(asset("frontEnd/assets/image/iconProfilePicture.7975761176487dc62e25536d9a36a61d.png")); ?>" alt="">
                </div>
                <div class="box_input">
                  <label for="Name"><?php echo e(__("post.Name")); ?></label>
                  <input type="text" id="Name" class="input" name="user_name" value="<?php echo e(old("user_name", $ad->user_name)); ?>" />
                  <div class="error_message">
                    <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
              </div>
  
              <div class="box_input">
                <label for="mobile"><?php echo e(__("post.Mobile Phone Number")); ?></label>
                <input type="number" id="mobile" class="input" name="user_phone" value="<?php echo e(old("user_phone", $ad->user_phone)); ?>" />
                <div class="error_message">
                  <?php $__errorArgs = ['user_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="box_input">
                <label><?php echo e(__("post.Contact Method")); ?></label>

                <div class="flex mt-[1rem]">
                  <label for="radio_phone" class="radio_method <?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_phone" class="<?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="contact" <?php echo e(old("contact", $ad->contact) === "phone" ? "checked" : ""); ?> value="phone" />
                    <span><?php echo e(__("post.Phone number")); ?></span>
                  </label>
    
                  <label for="radio_chat" class="radio_method <?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_chat" class="<?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="contact" <?php echo e(old("contact", $ad->contact) === "chat" ? "checked" : ""); ?> value="chat" />
                    <span><?php echo e(__("post.chat")); ?></span>
                  </label>
    
                  <label for="radio_both" class="radio_method">
                    <input type="radio" id="radio_both" class="<?php echo e(App::getLocale() == "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="contact" <?php echo e(old("contact", $ad->contact) === "both" ? "checked" : ""); ?> value="both" />
                    <span><?php echo e(__("post.BOTH")); ?></span>
                  </label>
                </div>

                <div class="error_message">
                  <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="border bg-black"></div>
  
              <div class="box_input">
                <button type="submit"><?php echo e(__("post.update")); ?></button>
              </div>
            </form>
          </div>
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad)): ?>
<?php $component = $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad; ?>
<?php unset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad); ?>
<?php endif; ?><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/posts/edit_post.blade.php ENDPATH**/ ?>