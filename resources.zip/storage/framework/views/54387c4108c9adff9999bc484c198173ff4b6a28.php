<!DOCTYPE html>
<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />

    <?php if(App::getLocale() === "ar"): ?>
      <!-- STYLING -->
      <link rel="stylesheet" href="<?php echo e(asset("frontEnd/assets/css/ar/main.css")); ?>" />

      
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800;900;1000&display=swap" rel="stylesheet">
    <?php else: ?>
      <!-- STYLING -->
      <link rel="stylesheet" href="<?php echo e(asset("frontEnd/assets/css/en/main.css")); ?>" />

      <!-- FONTS OF SITE -->
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
      <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet"
      />
    <?php endif; ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>

    <title><?php echo e(config("app.name") . " " . "-" . " " . $title); ?></title>
  </head>
  <body>
    <header class="Ad_header">
      <div class="l-container">
        <div class="back_to_home">
          <a href="<?php echo e(route("index")); ?>"><?php echo e(__("messages.back to home")); ?></a>
        </div>
      </div>
    </header>

    <section class="post_offer">
      <div class="l-container">
        <div class="post_offer_header">
          <h1><?php echo e(__("post.POST YOUR AD")); ?></h1>
        </div>

        <div class="post_offer_content">
          <div class="post_offer_content-header">
            <h2><?php echo e(__("post.CHOOSE A CATEGORY")); ?></h2>
          </div>

          <div class="row">
            <div class="categories">
              <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="category" data-target="<?php echo e("." . $mainCategory->slug); ?>">
                  <div class="category_icon w-[2rem] h-[2rem]">
                    <img src="<?php echo e(asset("upload_files/main_categories/" . $mainCategory->thumbnail )); ?>" alt="">
                  </div>
                  <span class="category_body"><?php echo e($mainCategory->translate()->name); ?></span>
                  <span class="category_icon-arrow"
                    ><i class="bx bx-chevron-<?php echo e(App::getLocale() === "en" ? "right" : "left"); ?>"></i
                  ></span>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="sub_categories-content">
              <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="sub_categories <?php echo e($mainCategory->slug); ?>">
                  <?php $__currentLoopData = $mainCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sub_category">
                      <a href="<?php echo e(route("ad.post", [$mainCategory->slug, $subCategory->slug])); ?>"><?php echo e($subCategory->translate()->name); ?></a>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </section>

    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
      integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    ></script>

    <script>
      const categories = document.querySelectorAll(".categories .category");
      const sub_categories = document.querySelectorAll(
          ".sub_categories-content .sub_categories"
      );

      categories.forEach((category) => {
          category.onclick = (ele) => {
              categories.forEach((category) => {
                  category.classList.remove("active");
              });

              sub_categories.forEach((sub_category) => {
                  sub_category.classList.remove("active");
              });

              ele.currentTarget.classList.add("active");
              document
                  .querySelector(ele.currentTarget.dataset.target)
                  .classList.add("active");
          };
      });
    </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/ad/sell.blade.php ENDPATH**/ ?>