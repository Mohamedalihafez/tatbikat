<header class="header-r">
    <div class="l-container">
      <div class="back_to_home">
        <a href="<?php echo e(route("index")); ?>"><?php echo e(__("messages.back to home")); ?></a>
      </div>
    </div>
  </header><?php /**PATH C:\Users\alimo\OneDrive\Desktop\project_suadia\onfire.tutbekat.com\resources\views/components/layouts/guest/inc/header.blade.php ENDPATH**/ ?>