
<?php if (isset($component)) { $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad = $component; } ?>
<?php $component = App\View\Components\Layouts\FrontEnd\Application::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.front-end.application'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\FrontEnd\Application::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <section class="offer">
        <div class="l-container">
          <div class="offer_row">
            <div class="all_details">
              <div class="thumbnails">
                <div class="container_thumbnails">
                  <div class="active_thumbnail">
                    <img
                      src="<?php echo e(asset("upload_files/ads/" . $ad->pictures[0]->thumbnail)); ?>"
                      class="active_image"
                      alt=""
                    />
                  </div>

                  <div class="box_thumbnails overflow-x-scroll">
                    <?php $__currentLoopData = $ad->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="box_thumbnail">
                        <img
                          src="<?php echo e(asset("upload_files/ads/" . $picture->thumbnail)); ?>"
                          alt=""
                          class="thumbnail mb-[0.5rem]"
                        />
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
              </div>
  
              <div class="offer_all_detials">
                <div class="all-details">
                  <div class="headline">
                    <h1><?php echo e(__("my_ads.details")); ?></h1>
                  </div>
  
                  <div class="cols">
                    <div class="col">
                      <p><?php echo e(__("my_ads.brand")); ?></p>
                      <p><?php echo e(__("my_ads.price type")); ?></p>
                      <p><?php echo e(__("my_ads.is deliverable")); ?></p>
                    </div>
  
                    <div class="col">
                      <p><?php echo e($ad->brand_id ? $ad->brand->name : " "); ?></p>
                      <p><?php echo e(__("my_ads.price")); ?></p>
                      <p><?php echo e(__("my_ads.no")); ?></p>
                    </div>
  
                    <div class="col">
                      <p><?php echo e(__("my_ads.price")); ?></p>
                      <p><?php echo e(__("my_ads.condition")); ?></p>
                    </div>
  
                    <div class="col">
                      <p><?php echo e($ad->price); ?></p>
                      <p><?php echo e($ad->condition); ?></p>
                    </div>
                  </div>
                </div>
  
                <div class="all-details">
                  <div class="headline">
                    <h1><?php echo e(__("my_ads.description")); ?></h1>
                  </div>
  
                  <div class="prog">
                    <p>
                      <?php echo e($ad->description); ?>

                    </p>
                  </div>
                </div>

                <?php if(auth()->guard()->check()): ?>
                  <?php if($ad->user->id === auth()->user()->id): ?>
                    <div class="my-[1.5rem] flex">
                      <a href="<?php echo e(route("posts.edit", $ad->slug)); ?>" class=" bg-yellow-600 text-[#f1f1f1] text-[1rem] uppercase font-[700] py-[0.5rem] px-[1.2rem] rounded-md"><?php echo e(__("my_ads.edit")); ?></a>

                      <form action="<?php echo e(route("posts.destroy", $ad->slug)); ?>" method="post" class="<?php echo e(App::getLocale() == "en" ? "ml-[1rem]" : "mr-[1rem]"); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>

                        <button type="submit" class=" bg-red-700 text-[#f1f1f1] text-[1rem] uppercase font-[700] py-[0.5rem] px-[1.2rem] rounded-md"><?php echo e(__("my_ads.delete")); ?></button>
                      </form>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
  
            <div class="offer_details">
              <div class="box_details">
                <div class="box_details-row">
                  <h1 class="uppercase"><?php echo e(__("my_ads.egp") . " " . $ad->price); ?></h1>

                  <?php if(auth()->guard()->check()): ?>
                  <div class="icon" id="favorate">
                    <form method="post" id="form_fav">         

                      <input type="hidden" id="ad_id" value="<?php echo e($ad->id); ?>">

                      <button type="submit" class="">
                        <i class="bx <?php echo e(auth()->user()->favoriteHas($ad->id) ? "bxs-heart" : "bx-heart"); ?> font-[600]" id="heart"></i>
                      </button>
                    </form>
                  </div>
                  <?php endif; ?>
                </div>

                <h2 class="text-[0.9rem] font-[700] text-gray-600"><?php echo e($ad->name); ?></h2>

                <div class="my-[1rem] flex flex-col">
                  <h2 class="text-[1.1rem] font-[700] text-black capitalize"><?php echo e(__("my_ads.share on social media")); ?></h2>

                  <div class="flex mt-[0.5rem]">
                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route("posts.show", $ad->slug)); ?>" 
                      target="_block" 
                      class="flex justify-center items-center h-12 w-12 bg-gray-300 rounded-full text-[1.5rem] mr-[1rem]"
                    >
                      <i class='bx bxl-facebook'></i>
                    </a>
  
                    <a href="https://www.twitter.com/intent/tweet/?text=<?php echo e($ad->name); ?>&url=<?php echo e(route("posts.show", $ad->slug)); ?>" 
                      target="_block" 
                      class="flex justify-center items-center h-12 w-12 bg-gray-300 rounded-full text-[1.5rem] mr-[1rem]"
                    >
                      <i class='bx bxl-twitter' ></i>
                    </a>
                  </div>
                </div>

                <div class="city">
                  <div class="prog">
                    <p><?php echo e($ad->city->name . ", " . $ad->governorate->name); ?></p>
                  </div>
                  <div class="time">
                    <p><?php echo e($ad->created_at->diffForHumans()); ?></p>
                  </div>
                </div>
              </div>
  
              <div class="box_details">
                <div class="headline">
                  <h2 class="capitalize"><?php echo e(__("my_ads.seller description")); ?></h2>
                </div>

                <div class="user_row cursor-pointer hover:bg-slate-300 rounded-[0.5rem] p-[0.2rem]">
                  <div class="box_img">
                    <img src="https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=<?php echo e($ad->user->name); ?>" alt="<?php echo e($ad->user->name); ?>" />
                  </div>
  
                  <div class="user_details flex-1">
                    <h1><?php echo e($ad->user->name); ?></h1>
                    <h4 class="capitalize"><?php echo e(__("my_ads.member since") . " " . $ad->user->created_at->diffForHumans()); ?></h4>
                  </div>
  
                  <div class="icon">
                    <i class="bx bx-chevron-<?php echo e(App::getLocale() === "en" ? "right" : "left"); ?>"></i>
                  </div>
                </div>

                <?php if($ad->contact == "both" || $ad->contact == "chat"): ?>
                <a href="<?php echo e(url("/chatify")); ?>">
                  <div class="w-full my-7">
                    <div class="w-full py-[0.7rem] bg-yellow-600 text-[#f1f1f1] rounded-lg border-[1px] border-yellow-600 hover:bg-transparent hover:text-yellow-600">
                      <h2 class="w-full text-center font-[700] text-[1rem]"><?php echo e(__("my_ads.send message")); ?></h2>
                    </div>
                  </div>
                </a> 
                <?php endif; ?>

                <?php if($ad->contact == "both" || $ad->contact == "phone"): ?>
                <div class="w-full mt-4">
                  <div class="w-full pl-[1rem]">
                    <h2 class="font-[700] text-[1rem]"><?php echo e(__("my_ads.tel") . " : " . $ad->user_phone); ?></h2>
                  </div>
                </div>
                <?php endif; ?>
              </div>
  
              <div class="box_details">
                <div class="headline_safety">
                  <h2><?php echo e(__("my_ads.your safety matters to us")); ?></h2>
                </div>
  
                <div class="safety_details">
                  <div class="safety_details-row">
                    <span>*</span>
                    <span
                      ><?php echo e(__("my_ads.only meet in public / crowded places for example metro stations and malls")); ?>.</span
                    >
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script>
          const active_thumbnail = document.querySelector(
              ".active_thumbnail .active_image"
          );
          const thumbnails = document.querySelectorAll(".thumbnail");

          thumbnails.forEach((thumbnail) => {
              thumbnail.onclick = (ele) => {
                  active_thumbnail.src = ele.currentTarget.src;
              };
          });

          
          $(function() {
            $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });

            $("#form_fav").on("submit", function (e) {
              e.preventDefault();

              let ad_id = $("#ad_id").val();

              if($("#heart").hasClass("bx-heart")){

                $.ajax({
                  type: "POST",
                  url: "<?php echo e(route('posts.favorite')); ?>",
                  headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
                  data: {
                    "ad_id": ad_id
                  },
                  cache: false,

                  success: function (response) {
                    $("#heart").removeClass("bx-heart");
                    $("#heart").addClass("bxs-heart");
                  }
                });

                

              }else{

                $.ajax({
                  type: "POST",
                  url: "<?php echo e(route('posts.favorite.delete')); ?>",
                  headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
                  data: {
                    "ad_id": ad_id
                  },
                  cache: false,

                  success: function (response) {
                    $("#heart").removeClass("bxs-heart");
                    $("#heart").addClass("bx-heart");
                  }
                });
              }
            });
          });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad)): ?>
<?php $component = $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad; ?>
<?php unset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad); ?>
<?php endif; ?><?php /**PATH C:\Users\alimo\OneDrive\Desktop\project_suadia\onfire.tutbekat.com\resources\views/posts/post.blade.php ENDPATH**/ ?>