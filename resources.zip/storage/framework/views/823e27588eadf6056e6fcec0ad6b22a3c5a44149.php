

<?php if (isset($component)) { $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad = $component; } ?>
<?php $component = App\View\Components\Layouts\FrontEnd\Application::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.front-end.application'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\FrontEnd\Application::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <section class="container m-auto min-h-[100vh] px-[3rem]">
        <div class="flex items-center my-[1rem]">
            <h2 class="mr-[0.5rem] text-[0.9rem] p-[0.5rem] uppercase text-[#000000] font-[500] border-b-[0.2rem] border-black">
                <a href="<?php echo e(route("users.my-ads")); ?>"><?php echo e(__("my_ads.ads")); ?></a>
            </h2>
            <h2 class="text-[0.9rem] p-[0.5rem] uppercase font-[500] text-[#000000]">
                <a href="<?php echo e(route("users.favorites")); ?>"><?php echo e(__("my_ads.favorites")); ?></a>
            </h2>
        </div>

        <div class="flex flex-col lg:flex-row justify-between items-center">
            <div class="mb-[0.5rem] lg:mb-[0]">
                <div class="w-[17rem] md:w-[25rem] sm:w-[20rem] flex items-center bg-white border-[0.1rem] border-slate-400 px-[0.5rem]">
                    <i class="bx bx-search text-[1.5rem]"></i>
                    <input type="text" id="search" class="border-0 outline-none w-full" placeholder="<?php echo e(__("my_ads.search by ad title or id")); ?>">
                </div>
            </div>

            <div class="">
                <select id="category" class="w-[17rem] md:w-[25rem] sm:w-[20rem]">
                    <option selected disabled>
                        <?php echo e(__("my_ads.filter by category")); ?>

                    </option>
                    
                    <?php $__currentLoopData = App\Models\MainCategory::where("status", "active")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-category-selected','data' => ['mainCategory' => $mainCategory]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-category-selected'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['main_category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($mainCategory)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="my-[1rem] flex items-center flex-wrap lg:flex-nowrap gap-2" id="links">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-ads-link','data' => ['class' => 'my_ads_link','adsCount' => $ads_count,'dataVal' => ''.e(Auth::user()->id).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('my-ads-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'my_ads_link','ads_count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ads_count),'data-val' => ''.e(Auth::user()->id).'']); ?>
                <?php echo e(__("my_ads.view all")); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-ads-link','data' => ['class' => 'my_ads_link','adsCount' => $ads_active_count,'dataVal' => 'active']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('my-ads-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'my_ads_link','ads_count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ads_active_count),'data-val' => 'active']); ?>
                <?php echo e(__("my_ads.active ads")); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-ads-link','data' => ['class' => 'my_ads_link','adsCount' => $ads_inactive_count,'dataVal' => 'inactive']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('my-ads-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'my_ads_link','ads_count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ads_inactive_count),'data-val' => 'inactive']); ?>
                <?php echo e(__("my_ads.inactive ads")); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-ads-link','data' => ['class' => 'my_ads_link','adsCount' => $ads_pending_count,'dataVal' => 'pending']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('my-ads-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'my_ads_link','ads_count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ads_pending_count),'data-val' => 'pending']); ?>
                <?php echo e(__("my_ads.pending ads")); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-ads-link','data' => ['class' => 'my_ads_link','adsCount' => $ads_moderated_count,'dataVal' => 'moderated']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('my-ads-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'my_ads_link','ads_count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ads_moderated_count),'data-val' => 'moderated']); ?>
                <?php echo e(__("my_ads.moderated ads")); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>

        <div class="grid lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-4 my-[1.5rem]" id="my_ads">
            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ad-card','data' => ['ad' => $ad,'class' => 'border-[1px] border-slate-500 rounded-[0.5rem] overflow-hidden']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ad-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ad' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ad),'class' => 'border-[1px] border-slate-500 rounded-[0.5rem] overflow-hidden']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).on("click", ".my_ads_link", function (e) {
                e.preventDefault();
                let data = $(this).attr("data-val");
                

                if (data === "<?php echo e(Auth::user()->id); ?>") {

                    $.ajax({
                        type: "GET", 
                        url: '<?php echo e(route("users.my_ads.filter")); ?>',
                        data: {
                            "user_id": data
                        },
                        cache: false,

                        success: function (response) {
                            $("#my_ads").html(response);
                        }
                    });

                } else {

                    $.ajax({
                        type: "GET", 
                        url: '<?php echo e(route("users.my_ads.filter")); ?>',
                        data: {
                            "status": data
                        },
                        cache: false,

                        success: function (response) {
                            $("#my_ads").html(response);
                        }
                    });
                }
            });

            $(document).on("keyup", "#search", function (e) {

                let data = $(this).val();

                $.ajax({
                    type: "GET", 
                    url: '<?php echo e(route("users.my_ads.filter")); ?>',
                    data: {
                        "search": data
                    },
                    cache: false,

                    success: function (response) {
                        $("#my_ads").html(response);
                    }
                });

            });

            $(document).on("change", "#category", function (e) {

                let data = $(this).find(":selected").val();

                $.ajax({
                    type: "GET", 
                    url: '<?php echo e(route("users.my_ads.filter")); ?>',
                    data: {
                        "category": data
                    },
                    cache: false,

                    success: function (response) {
                        $("#my_ads").html(response);
                    }
                });

            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad)): ?>
<?php $component = $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad; ?>
<?php unset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad); ?>
<?php endif; ?><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/user/my_ads.blade.php ENDPATH**/ ?>