<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['ads_count']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['ads_count']); ?>
<?php foreach (array_filter((['ads_count']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(["class" => App::getLocale() === "ar" ? "ml-[0.5rem]" : "mr-[0.5rem]"])); ?>>
    <a href="" class="border-[0.1rem] border-slate-600 px-[0.5rem] py-[0.8rem] rounded-[0.2rem] flex items-center">
        <span class="capitalize text-[0.9rem] font-[600] <?php echo e(App::getLocale() === "ar" ? "ml-[0.5rem]" : "mr-[0.5rem]"); ?>"><?php echo e($slot); ?></span>
        <span class="text-[0.8rem] font-[500]">(<?php echo e($ads_count); ?>)</span>
    </a>
</div><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/components/my-ads-link.blade.php ENDPATH**/ ?>