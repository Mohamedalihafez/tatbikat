<header class="header">
    <div class="header-inputs">
      <div class="l-container">
        <div class="logo">
          <h1><a class="text-black" href="<?php echo e(route("index")); ?>"><?php echo e(__("messages.fire")); ?></a></h1>
        </div>

        <div class="form">
          <div class="form_content">
            <div class="categories">
              <select name="category_governorate_id" id="category_governorate_id">
                <option disabled selected><?php echo e(__("messages.select your city")); ?></option>
                <?php $__currentLoopData = App\Models\Governorate::where("status", "active")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($governorate->id); ?>"><?php echo e($governorate->translate()->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
  
            <div class="search-box">
              <input
                type="text"
                name="search"
                id="search_home"
                placeholder="<?php echo e(__("messages.searching for what")); ?>"
              />
              <button>
                <i class="bx bx-search"></i>
              </button>
            </div>
          </div>
        </div>

        <div class="links">

          <div class="<?php echo e(App::getLocale() === "ar" ? "sm:ml-[1rem] lg:ml-[0.5rem]" : "sm:mr-[1rem] lg:mr-[0.5rem]"); ?>">
            <ul>
              <li class="lang relative px-[0.5rem] py-[0.2rem] cursor-pointer hover:underline">
                <span class="text-[1rem] font-[700] capitalize"><?php echo e(__("messages.language")); ?></span>

                <ul class="subMenu absolute py-[1.5rem] w-[10rem] left-0 bg-white z-[10001]">
                  <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="w-full">
                      <a class="w-full flex items-center justify-center mb-[0.5rem] text-[1rem] font-[600] capitalize hover:underline" rel="alternate" hreflang="<?php echo e($localeCode); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                        <?php echo e($properties['native']); ?>

                      </a>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </li>
            </ul>
          </div>
          
          <?php if(auth()->guard()->check()): ?>
            <div class="<?php echo e(App::getLocale() === "en" ? "sm:mr-[1rem]" : "sm:ml-[1rem]"); ?>">
              <a href="<?php echo e(url("/chatify")); ?>" class="flex items-center p-[0.5rem] hover:bg-slate-300 rounded-full">
                <i class='bx bx-message-square-dots text-[2.1rem]'></i>
              </a>
            </div>

            <div class="profile" id="profile_icon">
              <div class="profile_link">
                <span>
                  <img
                    src="<?php echo e(asset("frontEnd/assets/image/iconProfilePicture.7975761176487dc62e25536d9a36a61d.png")); ?>"
                    alt=""
                  />
                </span>
                <span><i class="bx bx-chevron-down"></i></span>

                <ul class="sub_menu" id="subMenuProfile">
                  <li class="sub_menu-link">
                    <a href="<?php echo e(route("users.wallet")); ?>">
                      <i class='bx bx-credit-card'></i>
                      <div>
                        <p><?php echo e(__("messages.fire wallet")); ?></p>
                        <p class="text-[0.73rem]"><?php echo e(__("messages.balance") . ":" . " " . auth()->user()->wallet_balance . " " . __("messages.egp")); ?></p>
                      </div>
                    </a>
                  </li>

                  <div class="border"></div>

                  <li class="sub_menu-link">
                    <a href="<?php echo e(route("profile.show")); ?>"><i class="bx bx-user"></i><?php echo e(__("messages.my profile")); ?></a>
                  </li>

                  <div class="border"></div>

                  <li class="sub_menu-link">
                    <a href="<?php echo e(route("users.my-ads")); ?>"><i class="bx bx-cart-add"></i><?php echo e(__("messages.my ads")); ?></a>
                  </li>

                  <div class="border"></div>

                  <li class="sub_menu-link">
                    <form action="<?php echo e(route("logout")); ?>" method="post">
                      <?php echo csrf_field(); ?>

                      <button class="flex items-center w-full py-[0.8rem] px-[0.5rem] capitalize font-[500] focus:outline-none hover:bg-[#ffb600] hover:text-white" type="submit"><i class="bx bx-log-out text-[1.8rem] leading-none <?php echo e(App::getLocale() === "ar" ? "ml-[1rem]" : "mr-[1rem]"); ?>"></i><?php echo e(__("messages.logout")); ?></button>
                    </form>
                  </li>
                </ul>
              </div>
            </div>
          <?php endif; ?>

          <?php if(auth()->guard()->guest()): ?>
            <div class="sign-in">
              <a href="<?php echo e(route("login")); ?>" class="capitalize"><?php echo e(__("messages.login")); ?></a>
            </div>
          <?php endif; ?>

          <div class="sell">
            <a href="<?php echo e(route("ad.sell")); ?>"
              ><i class="bx bx-plus"></i><span class="ml-[0.3rem] uppercase"><?php echo e(__("messages.sell")); ?></span></a
            >
          </div>
        </div>

        <div class="toggles">
          <i class="bx bx-align-middle"></i>
        </div>
      </div>
    </div>

    <nav class="nav">
      <div class="l-container">
        <ul>
          <?php $__currentLoopData = App\Models\MainCategory::where("status", "active")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <?php echo e($mainCategory->translate()->name); ?>


            <ul class="submenu">
              <?php $__currentLoopData = $mainCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sub-menu-link','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sub-menu-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                  <a href="<?php echo e(route("home.category", $subCategory->slug)); ?>"><?php echo e($subCategory->translate()->name); ?></a>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <div class="close">
          <i class="bx bx-x"></i>
        </div>
      </div>
    </nav>
  </header><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/components/layouts/front-end/inc/header.blade.php ENDPATH**/ ?>