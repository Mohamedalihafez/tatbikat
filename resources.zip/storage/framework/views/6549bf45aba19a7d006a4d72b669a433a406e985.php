

<?php if (isset($component)) { $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad = $component; } ?>
<?php $component = App\View\Components\Layouts\FrontEnd\Application::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.front-end.application'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\FrontEnd\Application::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <section class="min-h-[100vh] px-[3rem]">
        <div class="flex items-center my-[1rem]">
            <h2 class="mr-[0.5rem] text-[0.9rem] p-[0.5rem] uppercase text-[#000000] font-[500]">
                <a href="<?php echo e(route("users.my-ads")); ?>">ads</a>
            </h2>
            <h2 class="text-[0.9rem] p-[0.5rem] uppercase font-[500] text-[#000000] border-b-[0.2rem] border-black">
                <a href="<?php echo e(route("users.favorites")); ?>">favorites</a>
            </h2>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 my-[1.5rem]">
            <?php $__currentLoopData = $favorite_ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border-[1px] border-slate-500 rounded-[3px]">
                    <div class="w-full h-[10rem] bg-slate-400">
                        <img class="w-full h-full object-cover" src="<?php echo e(asset("upload_files/ads/" . $ad->thumbnail)); ?>" alt="<?php echo e($ad->name); ?>">
                    </div>

                    <div class="p-[1rem]">
                        <div class="my-[0.5rem]">
                            <a href="<?php echo e(route("posts.show", $ad->slug)); ?>">
                                <h1 class="text-[0.9rem] capitalize font-[500] text-[#000000]"><?php echo e($ad->name); ?></h1>
                            </a>
                        </div>
                        <div class="mb-[1.5rem]">
                            <h1 class="text-[1.1rem] capitalize font-[700] text-[#000000]"><?php echo e(__("my_ads.egp") . " " . $ad->price); ?></h1>
                        </div>
                        <div class="mb-[0.5rem]">
                            <p class="text-[0.8rem] capitalize font-[400] text-[#000000]"><?php echo e($ad->city->name . ", " . $ad->governorate->name); ?></p>
                        </div>
                        <div>
                            <p class="text-[0.8rem] capitalize font-[400] text-[#000000]"><?php echo e($ad->created_at->diffForHumans()); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad)): ?>
<?php $component = $__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad; ?>
<?php unset($__componentOriginal096dd318b3bf3bc77dabcb69362f42941baa4aad); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/user/favorites.blade.php ENDPATH**/ ?>