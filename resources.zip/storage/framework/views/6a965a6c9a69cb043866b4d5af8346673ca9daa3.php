

<option class="font-[700]" disabled><?php echo e($mainCategory->name); ?></option>
<div>
    <?php $__currentLoopData = $mainCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option class="font-[300]" value="<?php echo e($subCategory->id); ?>"><?php echo e($subCategory->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/components/main-category-selected.blade.php ENDPATH**/ ?>