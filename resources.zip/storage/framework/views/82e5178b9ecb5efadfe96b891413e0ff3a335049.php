<a href="<?php echo e(route("admin.offers.edit", $id)); ?>" class="edit btn btn-success btn-sm"><?php echo e(__("admin.Edit")); ?></a>

<form action="<?php echo e(route("admin.offers.destroy", $id)); ?>" style="display: inline-block" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("DELETE"); ?>

    <button type="submit" class="delete btn btn-danger btn-sm"><?php echo e(__("admin.Delete")); ?></button>
</form><?php /**PATH C:\Users\alimo\OneDrive\Desktop\project_suadia\onfire.tutbekat.com\resources\views/admin/offers/dataTables/actions.blade.php ENDPATH**/ ?>