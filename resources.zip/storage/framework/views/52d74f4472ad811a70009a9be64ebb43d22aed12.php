

<li class="sub_menu-link">
    <?php echo e($slot); ?>

</li><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/components/sub-menu-link.blade.php ENDPATH**/ ?>