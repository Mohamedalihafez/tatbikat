

<?php if($selectedConversation): ?>
    <div class="w-full h-[32rem] flex flex-col">
        <div class="w-full h-[4.3rem] border-b-[0.1rem] border-slate-400 px-[1rem] flex items-center">
            <div id="left_arrow_alt" class="flex items-center justify-center rounded-full mr-[1rem] w-[2.5rem] h-[2.5rem] hover:bg-slate-200 cursor-pointer overflow-hidden">
                <i class='bx bx-left-arrow-alt text-[2.5rem]'></i>
            </div>

            <div class="flex flex-1 items-center overflow-hidden">
                <div class="w-[2.5rem] h-[2.5rem] rounded-full bg-slate-300 overflow-hidden mr-[0.5rem]">
                    <img src="https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=<?php echo e($receiverInstance->name); ?>" alt="" class="w-full h-full object-cover">
                </div>

                <div class="truncate">
                    <h1 class="font-[800] text-[#000000] text-[0.95rem]"><?php echo e($receiverInstance->name); ?></h1>
                </div>
            </div>

            <div class="flex items-center justify-between w-[7.5rem]">
                <div class="cursor-pointer"><i class='bx bx-image text-[2rem] text-blue-500'></i></div>
                <div class="cursor-pointer"><i class='bx bx-phone text-[2rem] text-blue-500'></i></div>
                <div class="cursor-pointer"><i class='bx bx-info-circle text-[2rem] text-blue-500'></i></div>
            </div>
        </div>

        <div class="chatbox_body flex-1 flex flex-col overflow-x-hidden overflow-y-auto p-[1rem]">
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div 
                    wire:key="<?php echo e($message->id); ?>" 
                    class="min-w-[5rem] mb-[0.5rem] p-[0.5rem] rounded-[0.7rem] inline-block <?php echo e(Auth::user()->id == $message->sender_id ? "ml-auto bg-blue-600 rounded-br-[0]" : "bg-slate-200 rounded-bl-[0]"); ?>" 
                    style="width: 80%; max-width:80%; max-width: max-content;"
                >
                    <p class="text-[0.85rem] text-[#000000] break-words <?php echo e(Auth::user()->id == $message->sender_id ? "text-[#f1f1f1]" : ""); ?>">
                        <?php echo e($message->body); ?>

                    </p>

                    <div class="flex items-center justify-end">
                        <span class="text-[0.7rem] text-black mr-[0.5rem] uppercase <?php echo e(Auth::user()->id == $message->sender_id ? "text-slate-200" : ""); ?>"><?php echo e($message->created_at->format("m: i a")); ?></span>
                        <span><i class='bx bx-check text-[1rem] <?php echo e(Auth::user()->id == $message->sender_id ? "text-white" : "hidden"); ?>'></i></span>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <script>
            $(".chatbox_body").on("scroll", function() {
                var top = $(".chatbox_body").scrollTop();

                if(top == 0){
                    window.livewire.emit("loadmore");
                }
            });

            window.addEventListener("updatedHeight", event => {
                let old = event.detail.height;
                let newHeight = $(".chatbox_body")[0].scrollHeight;
                let height = $(".chatbox_body").scrollTop(newHeight - old);

                window.livewire.emit("updateHeight", {
                    height: height
                });
            });
        </script>
    </div>
<?php else: ?>
    <div class="w-full h-full flex items-center justify-center">
        <p class="text-[1rem] font-[600] capitalize text-blue-700">no conversatoin selected</p>
    </div>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        window.addEventListener("rowChatToBottom", event => {
            $(".chatbox_body").scrollTop($(".chatbox_body")[0].scrollHeight);
        });
    </script>    
<?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/livewire/chat/chatbox.blade.php ENDPATH**/ ?>