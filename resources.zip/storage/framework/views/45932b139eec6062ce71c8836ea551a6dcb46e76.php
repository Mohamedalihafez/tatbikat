
<?php if (isset($component)) { $__componentOriginal39d162072dc6d9c61b3ccf6b0ba8bb53881499f4 = $component; } ?>
<?php $component = App\View\Components\Layouts\BackEnd\Application::resolve([] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.back-end.application'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\BackEnd\Application::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Brands/</span> Edit Brand</h4>

        <!-- Basic Layout -->
        <div class="row">
          <div class="col-xl">
            <div class="card mb-4">
              <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Edit Brand</h5>
                <small class="text-muted float-end">Edit Brand <?php echo e($brand->name); ?></small>
              </div>
              <div class="card-body">
                <form method="POST" action="<?php echo e(route("admin.brands.update", $brand->slug)); ?>" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field("PATCH"); ?>

                  <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="mb-3">
                      <label class="form-label" for="basic-icon-default-fullname"><?php echo e(__("admin.name" . " " . $locale)); ?></label>
                      <div class="input-group input-group-merge">
                          <span id="basic-icon-default-fullname2" class="input-group-text"
                              ><i class="bx bx-user"></i
                          ></span>
                          <input
                              type="text"
                              class="form-control"
                              id="basic-icon-default-fullname"
                              name="<?php echo e($locale . '[name]'); ?>"
                              placeholder="type here the name"
                              aria-label="John Doe"
                              autofocus
                              value="<?php echo e(old($locale . '.name', $brand->translate($locale)->name)); ?>"
                              aria-describedby="basic-icon-default-fullname2"
                          />
                      </div>
                      <div class="error">
                        <?php $__errorArgs = [$locale . '.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <p><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <div class="mb-3">
                    <label class="form-label" for="basic-icon-default-company">Slug</label>
                    <div class="input-group input-group-merge">
                        <span id="basic-icon-default-company2" class="input-group-text"
                            ><i class="bx bx-buildings"></i
                        ></span>
                        <input
                            type="text"
                            id="basic-icon-default-company"
                            class="form-control"
                            placeholder="Type here the slug"
                            name="slug"
                            value="<?php echo e(old("slug", $brand->slug)); ?>"
                            aria-describedby="basic-icon-default-company2"
                        />
                    </div>
                    <div class="error">
                      <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <div class="mb-3">
                    <div class="form-check">
                      <input
                        name="status"
                        class="form-check-input"
                        type="radio"
                        value="active"
                        id="active"
                        <?php echo e($brand->status == "active" ? "checked" : ""); ?>

                      />
                      <label class="form-check-label" for="active"> Active </label>
                    </div>

                    <div class="form-check">
                      <input
                        name="status"
                        class="form-check-input"
                        type="radio"
                        value="inactive"
                        id="inactive"
                        <?php echo e($brand->status == "inactive" ? "checked" : ""); ?>

                      />
                      <label class="form-check-label" for="inactive"> Inactive </label>
                    </div>
                  </div>

                  <div class="mb-3">
                    <label class="form-label" for="basic-icon-default-fullname">Picture</label>
                    <div class="input-group">
                        <label class="input-group-text" for="inputGroupFile01">Upload</label>
                        <input type="file" name="thumbnail" class="form-control" id="inputGroupFile01" />
                    </div>
                    <div class="error">
                      <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>

                  <button type="submit" class="btn btn-primary">Update</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal39d162072dc6d9c61b3ccf6b0ba8bb53881499f4)): ?>
<?php $component = $__componentOriginal39d162072dc6d9c61b3ccf6b0ba8bb53881499f4; ?>
<?php unset($__componentOriginal39d162072dc6d9c61b3ccf6b0ba8bb53881499f4); ?>
<?php endif; ?><?php /**PATH C:\Users\alimo\OneDrive\Desktop\project_suadia\onfire.tutbekat.com\resources\views/admin/brands/edit.blade.php ENDPATH**/ ?>