
<?php $__currentLoopData = $mainCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h6><?php echo e($subCategory->name); ?></h6>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\laravel\OnFire\resources\views/admin/categories/mainCategories/dataTables/subCategory.blade.php ENDPATH**/ ?>