
<form action="<?php echo e(route("admin.admins.update", $username)); ?>" style="display: inline-block" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PATCH"); ?>

    <button type="submit" class="delete btn btn-danger btn-sm"><?php echo e(__("admin.Delete from Admins")); ?></button>
</form><?php /**PATH /home/rws4g9houuha/public_html/onfire.tutbekat.com/resources/views/admin/admins/dataTables/actions.blade.php ENDPATH**/ ?>