
<!DOCTYPE html>
<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />

    <?php if(App::getLocale() === "ar"): ?>
      <!-- STYLING -->
      <link rel="stylesheet" href="<?php echo e(asset("frontEnd/assets/css/ar/main.css")); ?>" />

      
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800;900;1000&display=swap" rel="stylesheet">
    <?php else: ?>
      <!-- STYLING -->
      <link rel="stylesheet" href="<?php echo e(asset("frontEnd/assets/css/en/main.css")); ?>" />

      <!-- FONTS OF SITE -->
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
      <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet"
      />
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.min.js"></script>
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <title><?php echo e(config("app.name") . " " . "-" . " " . $title); ?></title>
  </head>
  <body>
    <header class="Ad_header">
      <div class="l-container">
        <div class="back_to_home">
          <a href="<?php echo e(route("index")); ?>"><?php echo e(__("messages.back to home")); ?></a>
        </div>
      </div>
    </header>

    <section class="create_offer">
        <div class="l-container">
          <div class="create_offer_header">
            <h1><?php echo e(__("post.POST YOUR AD")); ?></h1>
          </div>
  
          <div class="create_offer_content">
            <div class="create_offer_content-header">
              <h2><?php echo e(__("post.SELECTED CATEGORY")); ?></h2>
              <p><?php echo e($mainCategory->translate()->name . " " . "---" . " " . $subCategory->translate()->name); ?></p>
            </div>
  
            <form action="<?php echo e(route("ad.post.store")); ?>" id="form" method="POST" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>

              <div class="head_form">
                <h2><?php echo e(__("post.INCLUDE SOME DETAILS")); ?></h2>
              </div>
  
              
              <div class="box_input">
                <label for="Ad_title"><?php echo e(__("post.ad title")); ?></label>
                <input type="text" class="input" id="Ad_title" name="name" value="<?php echo e(old("name")); ?>" />
                <div class="error_message">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input">
                <label for="Ad_slug"><?php echo e(__("post.ad slug")); ?></label>
                <input type="text" class="input" id="Ad_slug" name="slug" value="<?php echo e(old("slug")); ?>" />
                <div class="error_message">
                  <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input">
                <label for="Brand"><?php echo e(__("post.brand")); ?> <span class="text-[0.75rem] text-slate-400"><?php echo e(__("post.option")); ?></span></label>
                <select name="brand_id" id="Brand">
                  <option selected disabled>
                    <?php echo e(__("post.choosing brand")); ?>

                  </option>

                  <?php $__currentLoopData = App\Models\Brand::where("status", "active")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(old("brand_id") == $brand->id ? "selected" : ""); ?> value="<?php echo e($brand->id); ?>">
                      <span><?php echo e($brand->translate()->name); ?></span>
                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="error_message">
                  <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input">
                <label><?php echo e(__("post.type")); ?> <span class="text-[0.75rem] text-slate-400"><?php echo e(__("post.option")); ?></span></label>

                <div class="flex mt-[1rem]">
                  <label for="radio_type_1" class="radio_method <?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_type_1" class="<?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="type" value="phone" />
                    <span>Phone number</span>
                  </label>

                  <label for="radio_type_2" class="radio_method <?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_type_2" class="<?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="type" value="chat" />
                    <span>chat</span>
                  </label>

                  <label for="radio_type_3" class="radio_method">
                    <input type="radio" id="radio_type_3" class="<?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="type" value="both" />
                    <span>BOTH</span>
                  </label>
                </div>

                <div class="error_message">
                  <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input">
                <label><?php echo e(__("post.condition")); ?> <span class="text-[0.75rem] text-slate-400"><?php echo e(__("post.option")); ?></span></label>

                <div class="flex mt-[1rem]">
                  <label for="radio_condition_new" class="radio_method <?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_condition_new" class="<?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="condition" value="new" />
                    <span><?php echo e(__("post.New")); ?></span>
                  </label>

                  <label for="radio_condition_old" class="radio_method <?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_condition_old" class="<?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="condition" value="used" />
                    <span><?php echo e(__("post.used")); ?></span>
                  </label>
                </div>

                <div class="error_message">
                  <?php $__errorArgs = ['condition'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              
              <div class="box_input">
                <label for="Description"><?php echo e(__("post.Description")); ?></label>
                <textarea name="description" id="Description"><?php echo e(old("description")); ?></textarea>
                <div class="error_message">
                  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="border bg-black"></div>
  
              
              <h2 class="uppercase font-[800] text-[1.25rem] mb-[0.7rem]"><?php echo e(__("post.set a price")); ?></h2>
              <div class="box_input">
                <label for="price"><?php echo e(__("post.price")); ?></label>
                <input type="number" class="input" id="price" name="price" value="<?php echo e(old("price")); ?>" />
                <div class="error_message">
                  <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="border bg-black"></div>

              
              <h2 class="uppercase font-[800] text-[1.25rem] mb-[0.7rem]"><?php echo e(__("post.UPLOAD UP PHOTOS")); ?></h2>
              <div class="box_input">
                <label for="photos"><?php echo e(__("post.upload basic photo")); ?></label>
                <input
                  type="file"
                  id="photos"
                  name="thumbnail"
                  class="custom-file-input input"
                  accept="image/png, image/jpeg"
                />
                <div class="error_message">
                  <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              
              <div class="box_input">
                <label for="photos"><?php echo e(__("post.upload up top 5 photos")); ?></label>
                <input
                  type="file"
                  id="photos"
                  name="thumbnails[]"
                  class="custom-file-input input"
                  accept="image/png, image/jpeg"
                  multiple
                />
                <div class="error_message">
                  <?php $__errorArgs = ['thumbnails'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="border bg-black"></div>

              
              <h2 class="uppercase font-[800] text-[1.25rem] mb-[0.7rem]"><?php echo e(__("post.YOUR AD'S location")); ?></h2>
              <div class="box_input">
                <label for="Brand"><?php echo e(__("post.Location")); ?></label>
                <select name="governorate_id" id="governorate_id">
                  <option selected disabled>
                    <?php echo e(__("post.Choosing Location") . "..."); ?>

                  </option>
  
                  <?php $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($governorate->id); ?>">
                      <span><?php echo e($governorate->translate()->name); ?></span>
                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="error_message">
                  <?php $__errorArgs = ['governorate_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              
              <div class="box_input" id="cities" style="">
                <label for="Brand"><?php echo e(__("post.Select Cities")); ?></label>
                <select name="city_id" id="city_id">
                </select>
                <div class="error_message">
                  <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="border bg-black"></div>
  
              <h2 class="text-[1.25rem] font-[800] mb-[1rem] uppercase text-black"><?php echo e(__("post.REVIEW YOUR DETAILS")); ?></h2>
  
              <div class="flex mb-[1.5rem]">
                <div class="w-[5.5rem] h-[5.5rem] rounded-full <?php echo e(App::getLocale() === "en" ? "mr-[1.3rem]" : "ml-[1.3rem]"); ?>">
                  <img class="w-full h-full" src="<?php echo e(asset("frontEnd/assets/image/iconProfilePicture.7975761176487dc62e25536d9a36a61d.png")); ?>" alt="">
                </div>

                <div class="box_input">
                  <label for="Name"><?php echo e(__("post.Name")); ?></label>
                  <input type="text" id="Name" class="input" name="user_name" value="<?php echo e(old("user_name", Auth::user()->name)); ?>" />
                  <div class="error_message">
                    <?php $__errorArgs = ['user_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
              </div>
  
              <div class="box_input">
                <label for="mobile"><?php echo e(__("post.Mobile Phone Number")); ?></label>
                <input type="number" id="mobile" class="input" name="user_phone" value="<?php echo e(old("user_phone")); ?>" />
                <div class="error_message">
                  <?php $__errorArgs = ['user_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="box_input">
                <label><?php echo e(__("post.Contact Method")); ?></label>

                <div class="flex mt-[1rem]">
                  <label for="radio_phone" class="radio_method <?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_phone" class="<?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="contact" <?php echo e(old("contact") == "phone" ? "checked" : ""); ?> value="phone" />
                    <span><?php echo e(__("post.Phone number")); ?></span>
                  </label>
    
                  <label for="radio_chat" class="radio_method <?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>">
                    <input type="radio" id="radio_chat" class="<?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="contact" <?php echo e(old("contact") == "chat" ? "checked" : ""); ?> value="chat" />
                    <span><?php echo e(__("post.chat")); ?></span>
                  </label>
    
                  <label for="radio_both" class="radio_method">
                    <input type="radio" id="radio_both" class="<?php echo e(App::getLocale() === "en" ? "mr-[.5rem]" : "ml-[.5rem]"); ?>" name="contact" <?php echo e(old("contact") == "phone" ? "both" : ""); ?> value="both" />
                    <span><?php echo e(__("post.BOTH")); ?></span>
                  </label>
                </div>

                <div class="error_message">
                  <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
  
              <div class="border bg-black"></div>

              <input type="hidden" name="main_category_id" value="<?php echo e($mainCategory->id); ?>">
              <input type="hidden" name="sub_category_id" value="<?php echo e($subCategory->id); ?>">
  
              <div class="box_input">
                <button type="submit"><?php echo e(__("post.Post now")); ?></button>
              </div>
            </form>
          </div>
        </div>
    </section>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"
      integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    ></script>

    <script type="text/javascript">
      $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
    </script>

    <script>
      $(function() {
        $(document).on("change", "#governorate_id", function() {
          let governorate_id = $(this).find(":selected").val();
          console.log(governorate_id);
          $.ajax({
            type: 'GET',
            url: '<?php echo e(route("filter")); ?>',
            data: { 'governorate': governorate_id },
            cache: false,

            success: function (response) {
              $("#cities").show();
              $("#city_id").html(response);
            },
          });
        });
      });
    </script>
  </body>
</html>
<?php /**PATH C:\Users\alimo\OneDrive\Desktop\project_suadia\onfire.tutbekat.com\resources\views/ad/post.blade.php ENDPATH**/ ?>