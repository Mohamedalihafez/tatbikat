
@foreach ($governorate->cities as $city)
    <h6>{{ $city->name }}</h6>
@endforeach