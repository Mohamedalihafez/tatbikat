
<h6>{{ $subCategory->mainCategory->name }}</h6>