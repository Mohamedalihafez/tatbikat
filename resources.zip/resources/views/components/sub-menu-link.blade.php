

<li class="sub_menu-link">
    {{ $slot }}
</li>