<header class="header-r">
    <div class="l-container">
      <div class="back_to_home">
        <a href="{{ route("index") }}">{{ __("messages.back to home") }}</a>
      </div>
    </div>
  </header>